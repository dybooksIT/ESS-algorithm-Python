for i in range(1, 51):
    if i % 3 == 0:
        print('Fizz', end=' ')
    else:
        print(i, end=' ')
a = 0b10010
print(a)
print(type(a))
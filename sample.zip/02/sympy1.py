from sympy import sieve

print([i for i in sieve.primerange(1, 200)])
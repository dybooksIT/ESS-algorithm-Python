a = 18
print(bin(a))
print(type(a))

b = '10010'
print(int(b, 2))
print(type(b))
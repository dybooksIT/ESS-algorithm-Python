from sympy import isprime

print(isprime(101))
insert_price = input('insert: ')
product_price = input('product: ')
change = int(insert_price) - int(product_price)
print(change)
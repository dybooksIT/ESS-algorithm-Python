a = [3]

def calc(a):
    a = [4]
    return a

print(a)
print(calc(a))
print(a)
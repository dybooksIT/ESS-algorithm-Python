x = 3

def calc(x):
    x += 4
    return x

print(x)
print(calc(x))
print(x)
# 소비세를 계산
# tax_rate1 = 0.08 # 소비세가 8%이므로 세율을 0.08로 함
tax_rate2 = 0.1 # 소비세는 10%이므로 세율을 0.1로 함

# print(tax_rate1)
print(tax_rate2)
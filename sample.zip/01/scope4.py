x = 10

def reset():
    x = 30
    print(x)

reset()
print(x)
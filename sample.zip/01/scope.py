x = 10

def check():
    a = 30
    return
url1 = 'https://archmond.net/archives/11551'
url2 = 'https://archmond.net' '/archives/11551'
url3 = 'https://archmond.net' \
       '/archives/11551'

print(url1)
print(url2)
print(url3)
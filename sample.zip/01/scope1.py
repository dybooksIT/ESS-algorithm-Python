x = 10

def check():
    a = 30
    print(x)
    print(a)
    return

check()
print(x)
print(a)
long_name_variable = 1111111111
if (long_name_variable == 1111111111) \
or (long_name_variable == 2222222222) \
or (long_name_variable == 3333333333):
    print('long value')
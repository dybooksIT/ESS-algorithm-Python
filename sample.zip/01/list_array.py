data = [4, 5, 2, 3, 6]

import array

data = array.array('i', [4, 5, 2, 3, 6])
print(data)
print(type(data))

import numpy

data = numpy.ndarray([4, 5, 2, 3, 6])
print(data)
print(type(data))
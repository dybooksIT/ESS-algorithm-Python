import func

print(func.add(3, 4))
x = 10

def update():
    x += 30
    print(x)

update()
print(x)
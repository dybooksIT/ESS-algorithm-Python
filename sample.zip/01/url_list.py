url_list = [
    'https://archmond.net',
    'https://www.dongyangbooks.co.kr',
    'http://m.dongyangbooks.com'
]

print(url_list)
x = 10

if True:
    a = 30
    print(x)
    print(a)

print(x)
print(a)
x = 10

def reset():
    global x
    x = 30
    print(x)

reset()
print(x)